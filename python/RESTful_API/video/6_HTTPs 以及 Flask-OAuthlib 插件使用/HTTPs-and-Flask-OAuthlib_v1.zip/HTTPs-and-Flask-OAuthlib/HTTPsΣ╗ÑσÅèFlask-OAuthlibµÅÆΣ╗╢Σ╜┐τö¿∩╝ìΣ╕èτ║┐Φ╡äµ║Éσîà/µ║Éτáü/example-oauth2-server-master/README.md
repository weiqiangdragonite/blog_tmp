# Example for OAuth 2 Server

This is an example of OAuth 2 Server.

Find more details on <http://lepture.com/en/2013/create-oauth-server>

# INSTALLATION

$ pip install -r requirements.txt
