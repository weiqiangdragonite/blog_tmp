#include "socket_includes.h"




int main(int argc, char *argv[])
{
	int sockfd;
	struct sockaddr_in server, client, broadcast;
	char buf[200]="hello.brocast.", read_buf[100];
	char dest[20];
	unsigned int len, length;	
	socklen_t len1;
	int rv;
	time_t timep;
	int on = 1;
	
	
	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if(sockfd < 0){
		perror("Create socket fail.");
		return -1;
	}		

	if(setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &on, sizeof(on))<0){
		perror("setsockopt:");
		return -1;
	}
	
	bzero(&server, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_port   = htons(8888);
	server.sin_addr.s_addr  = htonl(INADDR_ANY);
  
	bzero(&broadcast, sizeof(broadcast));
	broadcast.sin_family = AF_INET;
	broadcast.sin_port   = htons(8888);
	broadcast.sin_addr.s_addr  = inet_addr("192.168.1.255");
	
	len = sizeof(struct sockaddr);
	if(bind(sockfd, (struct sockaddr *)&server, len)<0){
		perror("bind error.");
		return -1;
	}
	len1 = sizeof(struct sockaddr_in);
	rv = sendto(sockfd, buf, strlen(buf), 0,
			(struct sockaddr *)&broadcast, len);
	if(rv < 0){
		perror("sendto:");
		return -1;
	}
  
  while(1){
	  rv = recvfrom(sockfd, read_buf, 100, 0, 
		  (struct sockaddr *)&client, &length);
	  if(rv < 0){
		  printf("recvfrom error.\n");
		  close(sockfd);
		  return -1;
	  }
	  printf("len: %d\n", rv);
	  printf("ip: %s, port:%d\n", inet_ntop(AF_INET, &client.sin_addr, dest, 20), ntohs(client.sin_port));
	  printf("read_buf:%s\n", read_buf);
  
	  timep = time(NULL);
	  snprintf(buf, sizeof(buf), "%s", ctime(&timep));
  
	  sendto(sockfd, buf, strlen(buf), 0,
		  (struct sockaddr*)&broadcast, length);
	  bzero(&client, length);
	  bzero(buf, 200);
	  bzero(read_buf, 100);
	  sleep(1);
  }

	close(sockfd);
	return 0;
  
}







