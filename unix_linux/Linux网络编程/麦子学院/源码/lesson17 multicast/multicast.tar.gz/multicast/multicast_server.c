#include "socket_includes.h"
#include <errno.h>




int main(int argc, char*argv)
{
    int sockfd;
    struct sockaddr_in mcast_addr;   
	char buf[100] = MCAST_DATA;
	int on = 1;
	int ret;
	
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);        
    if (sockfd == -1)
    {
        perror("socket()");
        return -1;
    }
   
	if((ret = setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on))) < 0){
	    perror("Error, set socket reuse addr failed");  
	    return -1;
	}
    memset(&mcast_addr, 0, sizeof(mcast_addr));
    mcast_addr.sin_family = AF_INET;              
    mcast_addr.sin_addr.s_addr = inet_addr(MCAST_ADDR);
    mcast_addr.sin_port = htons(MCAST_PORT);      
   
                                                  
    while(1) {
        int n = sendto(sockfd, buf, strlen(buf), 0,
					(struct sockaddr*)&mcast_addr,sizeof(mcast_addr));
        if( n < 0){
            perror("sendto:");
            return -1;
        }      
       
        sleep(MCAST_INTERVAL); 
    }
   
    return 0;
}
















