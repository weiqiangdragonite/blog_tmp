#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>


#include <unistd.h>
#include <fcntl.h>
#include <sys/epoll.h>



#define MAX_LISTEN_QUE 5


#define SERV_PORT 8888

#define MAX_BUFFER_SIZE 100

#define FD_MAXSIZE 1024
#define MAX_EVENTS 10

#define RT_ERR (-1)
#define RT_OK 0

#define MCAST_PORT 8888
#define MCAST_ADDR "224.25.25.25"
#define MCAST_DATA "Hello.Multicast!"           
#define MCAST_INTERVAL 3                        

#define BUFF_SIZE 256     


