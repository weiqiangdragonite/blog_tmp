#include "socket_includes.h"





int main(int argc, char *argv[])
{
	int sockfd;
	struct sockaddr_in servaddr;
	char buf[100], read_buf[100];
	int bytes;
	
	if(( sockfd = socket(AF_INET,SOCK_STREAM,0)) < 0 )
	{
		perror("socket error");
		return -1;
	}
	
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family		=		AF_INET;
	servaddr.sin_addr.s_addr=		inet_addr("192.168.1.108");
	servaddr.sin_port		=		htons(8888);
	
	if( connect(sockfd,(struct sockaddr*)&servaddr,sizeof(servaddr)) < 0 )
	{
		perror("connect error");
		return 0;
	}
	while(1){
		//fgets(buf, 100, stdin);

		//send(sockfd, buf, strlen(buf), 0);
		
		bytes = recv(sockfd, read_buf, 100, MSG_DONTWAIT);
		if(bytes < 0){
			printf("Error, read failed.\n");
			//return -1;
			usleep(10000);
			continue;
			}

		if(0 == bytes){
			printf("Server close connection.\n");
			return -1;
			}
		printf("Read bytes %d\n", bytes);
		printf("read_buf:%s\n", read_buf);
		
	}
	close(sockfd);
	return 0;
}



